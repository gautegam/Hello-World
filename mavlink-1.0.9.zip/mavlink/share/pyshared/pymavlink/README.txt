This is a python implementation of the MAVLink protocol. 

Please see http://www.qgroundcontrol.org/mavlink/pymavlink for
documentation
